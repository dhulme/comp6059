require 'test_helper'

class ReviewsHelperTest < ActionView::TestCase
end
