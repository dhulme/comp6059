class Category < ActiveRecord::Base
  has_many :templates
end
